# EVP-KLEE: Enhanced Value Profiling for KLEE

EVP-KLEE is an automated symbolic execution pipeline that enhances KLEE with value profiling capabilities for improved performance and coverage analysis.

## 🚀 Quick Start with GitHub Codespace

The easiest way to get started with EVP-KLEE is using GitHub Codespace:

1. **Open in Codespace**: Click the "Code" button and select "Codespaces" → "Create codespace on main"
2. **Wait for setup**: The Codespace will automatically build the complete environment
3. **Verify installation**: Run `bash scripts/verify_environment.sh` to check everything is working
4. **Start developing**: The environment is ready to use!

### What's Included in the Codespace

- **Ubuntu 20.04** base environment
- **LLVM 10** and **Clang 10** with debug support
- **KLEE v2.3** with uClibc and POSIX runtime
- **STP** and **Z3** solvers
- **Python 3** with virtual environment
- **wllvm** for whole-program LLVM bitcode extraction
- **Complete development tools** (VS Code extensions, Git LFS, etc.)

## 📁 Project Structure

```
EVP-KLEE/
├── klee/                 # KLEE v2.3 source code
├── benchmarks/           # Test programs and benchmarks
│   ├── coreutils/        # Coreutils benchmarks
│   ├── busybox/          # BusyBox benchmarks
│   ├── apr/              # APR benchmarks
│   ├── m4/               # M4 benchmarks
│   └── custom/           # Custom benchmarks
├── scripts/              # Setup and automation scripts
├── experiments/          # Experiment configurations and results
├── docs/                 # Project documentation
├── results/              # Analysis results and statistics
├── build/                # KLEE build output
└── automated_demo/       # EVP pipeline demo scripts
    ├── config/           # Configuration files
    ├── drivers/          # Driver programs
    └── logs/             # Log files
```

## 🛠️ Manual Setup (Alternative to Codespace)

If you prefer to set up the environment manually:

### Prerequisites

- Ubuntu 20.04 or compatible Linux distribution
- Git, CMake, build-essential
- Python 3.8+

### Installation Steps

1. **Clone the repository**:
   ```bash
   git clone https://github.com/roxaw/evp-klee-artifact.git
   cd evp-klee-artifact
   ```

2. **Run the setup script**:
   ```bash
   bash scripts/startup_evp_klee.sh
   ```

3. **Build KLEE** (if not using Codespace):
   ```bash
   bash scripts/build_klee.sh
   ```

4. **Verify the environment**:
   ```bash
   bash scripts/verify_environment.sh
   ```

## 🎯 Usage

### Running the EVP Pipeline

1. **Basic usage**:
   ```bash
   cd automated_demo
   python3 evp_pipeline.py
   ```

2. **Process specific category**:
   ```bash
   python3 evp_pipeline.py coreutils
   ```

3. **Run with custom configuration**:
   ```bash
   python3 evp_pipeline.py --config config/custom_programs.json
   ```

### Available Scripts

- `scripts/startup_evp_klee.sh` - Initialize the development environment
- `scripts/build_klee.sh` - Build KLEE v2.3 from source
- `scripts/verify_environment.sh` - Verify all tools are installed correctly
- `scripts/setup_git.sh` - Configure Git with LFS support
- `scripts/setup_directories.sh` - Create workspace directory structure

## 🔧 Configuration

The EVP pipeline uses JSON configuration files to define programs and their properties:

```json
{
  "coreutils": {
    "type": "cli",
    "programs": ["cp", "chmod", "dd", "df", "du", "ln", "ls", "mkdir", "mv", "rm"],
    "thresholds": {"min_occurrence": 3, "max_values": 5}
  }
}
```

## 📊 Features

- **Automated Instrumentation**: Phase 1 integration with VASE pass
- **Batch Processing**: Process multiple programs efficiently
- **Value Profiling**: Enhanced value analysis for KLEE
- **Comprehensive Logging**: Detailed execution logs and statistics
- **Validation Framework**: Automated testing and validation
- **Artifact Management**: Organized output structure

## 🐛 Troubleshooting

### Common Issues

1. **KLEE not found**: Run `bash scripts/build_klee.sh` to build KLEE
2. **Permission denied**: Ensure scripts are executable with `chmod +x scripts/*.sh`
3. **Python module errors**: Activate the virtual environment with `source venv/bin/activate`
4. **LLVM version mismatch**: Ensure LLVM 10 is installed and configured

### Getting Help

- Check the logs in `automated_demo/logs/`
- Run `bash scripts/verify_environment.sh` to diagnose issues
- See `docs/TROUBLESHOOTING.md` for detailed solutions

## 📚 Documentation

- `docs/SETUP.md` - Detailed setup instructions
- `docs/USAGE.md` - Comprehensive usage guide
- `docs/ARCHITECTURE.md` - System architecture overview
- `docs/TROUBLESHOOTING.md` - Common issues and solutions

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests: `python3 test_environment.py`
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- KLEE symbolic execution engine
- LLVM project
- STP and Z3 solvers
- VASE instrumentation framework
